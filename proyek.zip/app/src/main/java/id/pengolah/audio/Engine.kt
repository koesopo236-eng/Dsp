package id.pengolah.audio

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink

/** Satu pemutar untuk seluruh aplikasi, dipakai oleh layar dan layanan latar belakang. */
object Engine {
    @Volatile
    private var instance: ExoPlayer? = null

    fun player(ctx: Context): ExoPlayer {
        val cur = instance
        if (cur != null) return cur
        synchronized(this) {
            val again = instance
            if (again != null) return again
            val app = ctx.applicationContext
            val factory = object : DefaultRenderersFactory(app) {
                override fun buildAudioSink(
                    context: Context,
                    enableFloatOutput: Boolean,
                    enableAudioTrackPlaybackParams: Boolean
                ): AudioSink {
                    return DefaultAudioSink.Builder(context)
                        .setAudioProcessors(arrayOf<AudioProcessor>(FxProcessor()))
                        .build()
                }
            }
            val attrs = AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build()
            val p = ExoPlayer.Builder(app, factory)
                .setAudioAttributes(attrs, true)
                .setHandleAudioBecomingNoisy(true)
                .setWakeMode(C.WAKE_MODE_LOCAL)
                .build()
            instance = p
            return p
        }
    }
}
