package id.pengolah.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Dipasang di jalur keluaran ExoPlayer. Menerima suara PCM 16-bit atau float,
 * mono atau stereo, lalu mengolah kanal kiri dan kanan secara terpisah.
 * Format lain dilewatkan tanpa efek.
 */
class FxProcessor : BaseAudioProcessor() {
    private val engine = StereoEngine()
    private var mono = false
    private var enc = C.ENCODING_PCM_16BIT

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val okEnc = inputAudioFormat.encoding == C.ENCODING_PCM_16BIT ||
            inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        val okCh = inputAudioFormat.channelCount == 1 || inputAudioFormat.channelCount == 2
        if (!okEnc || !okCh) return AudioProcessor.AudioFormat.NOT_SET
        mono = inputAudioFormat.channelCount == 1
        enc = inputAudioFormat.encoding
        engine.setRate(inputAudioFormat.sampleRate.toDouble())
        return AudioProcessor.AudioFormat(inputAudioFormat.sampleRate, 2, inputAudioFormat.encoding)
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        engine.sync()
        val isFloat = enc == C.ENCODING_PCM_FLOAT
        val bps = if (isFloat) 4 else 2
        val inFrame = if (mono) bps else bps * 2
        val frames = inputBuffer.remaining() / inFrame
        if (frames <= 0) {
            inputBuffer.position(inputBuffer.limit())
            return
        }
        val out = replaceOutputBuffer(frames * bps * 2)
        var pkL = 0f
        var pkR = 0f
        for (i in 0 until frames) {
            val l: Float
            val r: Float
            if (isFloat) {
                l = inputBuffer.getFloat()
                r = if (mono) l else inputBuffer.getFloat()
            } else {
                l = inputBuffer.getShort() / 32768f
                r = if (mono) l else inputBuffer.getShort() / 32768f
            }
            val yl = engine.l.process(l)
            val yr = engine.r.process(r)
            if (isFloat) {
                out.putFloat(yl)
                out.putFloat(yr)
            } else {
                out.putShort((yl * 32767f).roundToInt().coerceIn(-32768, 32767).toShort())
                out.putShort((yr * 32767f).roundToInt().coerceIn(-32768, 32767).toShort())
            }
        }
        pkL = engine.l.peakBlock
        pkR = engine.r.peakBlock
        engine.l.peakBlock = 0f
        engine.r.peakBlock = 0f
        Fx.peak[0] = max(Fx.peak[0], pkL)
        Fx.peak[1] = max(Fx.peak[1], pkR)
        Fx.gr[0] = engine.l.grBlock
        Fx.gr[1] = engine.r.grBlock
        out.flip()
    }

    override fun onFlush() {
        engine.reset()
    }

    override fun onReset() {
        engine.reset()
    }
}
