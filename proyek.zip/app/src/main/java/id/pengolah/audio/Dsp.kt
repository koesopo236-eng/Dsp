package id.pengolah.audio

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

const val T_PEAK = 0
const val T_LOW = 1
const val T_HIGH = 2
const val T_HP = 3
const val T_LP = 4

/** Satu pita EQ parametrik. type: 0 puncak, 1 rak rendah, 2 rak tinggi. */
class Band(var type: Int, var f: Double, var g: Double, var q: Double)

/** Semua pengaturan satu kanal (kiri atau kanan). */
class ChParams {
    var invert = false
    var mute = false
    var trimDb = 0.0
    var delayMs = 0.0

    var eqOn = true
    val eq = arrayOf(
        Band(T_PEAK, 80.0, 0.0, 1.0),
        Band(T_PEAK, 300.0, 0.0, 1.0),
        Band(T_PEAK, 1000.0, 0.0, 1.0),
        Band(T_PEAK, 3500.0, 0.0, 1.0),
        Band(T_PEAK, 10000.0, 0.0, 1.0)
    )

    var hpOn = false
    var hpF = 80.0
    var lpOn = false
    var lpF = 12000.0
    var slope = 24

    var compOn = false
    var thr = -24.0
    var ratio = 4.0
    var atk = 10.0
    var rel = 250.0
    var knee = 12.0
    var makeup = 0.0

    fun copyFrom(o: ChParams) {
        loadJson(o.toJson())
    }

    fun toJson(): JSONObject {
        val j = JSONObject()
        j.put("invert", invert)
        j.put("mute", mute)
        j.put("trim", trimDb)
        j.put("delay", delayMs)
        j.put("eqOn", eqOn)
        val a = JSONArray()
        for (b in eq) {
            val o = JSONObject()
            o.put("t", b.type)
            o.put("f", b.f)
            o.put("g", b.g)
            o.put("q", b.q)
            a.put(o)
        }
        j.put("eq", a)
        j.put("hpOn", hpOn)
        j.put("hpF", hpF)
        j.put("lpOn", lpOn)
        j.put("lpF", lpF)
        j.put("slope", slope)
        j.put("compOn", compOn)
        j.put("thr", thr)
        j.put("ratio", ratio)
        j.put("atk", atk)
        j.put("rel", rel)
        j.put("knee", knee)
        j.put("makeup", makeup)
        return j
    }

    fun loadJson(j: JSONObject?) {
        if (j == null) return
        invert = j.optBoolean("invert", invert)
        mute = j.optBoolean("mute", mute)
        trimDb = j.optDouble("trim", trimDb)
        delayMs = j.optDouble("delay", delayMs)
        eqOn = j.optBoolean("eqOn", eqOn)
        val a = j.optJSONArray("eq")
        if (a != null) {
            for (i in 0 until min(a.length(), eq.size)) {
                val o = a.optJSONObject(i) ?: continue
                eq[i].type = o.optInt("t", eq[i].type)
                eq[i].f = o.optDouble("f", eq[i].f)
                eq[i].g = o.optDouble("g", eq[i].g)
                eq[i].q = o.optDouble("q", eq[i].q)
            }
        }
        hpOn = j.optBoolean("hpOn", hpOn)
        hpF = j.optDouble("hpF", hpF)
        lpOn = j.optBoolean("lpOn", lpOn)
        lpF = j.optDouble("lpF", lpF)
        slope = j.optInt("slope", slope)
        compOn = j.optBoolean("compOn", compOn)
        thr = j.optDouble("thr", thr)
        ratio = j.optDouble("ratio", ratio)
        atk = j.optDouble("atk", atk)
        rel = j.optDouble("rel", rel)
        knee = j.optDouble("knee", knee)
        makeup = j.optDouble("makeup", makeup)
    }
}

/** Filter biquad (rumus RBJ Audio EQ Cookbook), bentuk Direct Form I. */
class Biquad {
    var active = false
    private var b0 = 1.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var a1 = 0.0
    private var a2 = 0.0
    private var x1 = 0.0
    private var x2 = 0.0
    private var y1 = 0.0
    private var y2 = 0.0

    fun reset() {
        x1 = 0.0; x2 = 0.0; y1 = 0.0; y2 = 0.0
    }

    fun process(x: Double): Double {
        val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1
        x1 = x
        y2 = y1
        y1 = y
        return y
    }

    fun magnitude(w: Double): Double {
        val c1 = cos(w)
        val s1 = sin(w)
        val c2 = cos(2.0 * w)
        val s2 = sin(2.0 * w)
        val nr = b0 + b1 * c1 + b2 * c2
        val ni = -(b1 * s1 + b2 * s2)
        val dr = 1.0 + a1 * c1 + a2 * c2
        val di = -(a1 * s1 + a2 * s2)
        return sqrt((nr * nr + ni * ni) / (dr * dr + di * di))
    }

    fun set(type: Int, f0: Double, gDb: Double, q0: Double, fs: Double) {
        val f = min(max(f0, 10.0), fs * 0.45)
        val q = max(q0, 0.05)
        val a = 10.0.pow(gDb / 40.0)
        val w = 2.0 * PI * f / fs
        val c = cos(w)
        val s = sin(w)
        var nb0 = 1.0
        var nb1 = 0.0
        var nb2 = 0.0
        var na0 = 1.0
        var na1 = 0.0
        var na2 = 0.0
        when (type) {
            T_PEAK -> {
                val al = s / (2.0 * q)
                nb0 = 1.0 + al * a
                nb1 = -2.0 * c
                nb2 = 1.0 - al * a
                na0 = 1.0 + al / a
                na1 = -2.0 * c
                na2 = 1.0 - al / a
            }
            T_LOW -> {
                val sa = 2.0 * sqrt(a) * (s / 2.0 * sqrt(2.0))
                nb0 = a * ((a + 1.0) - (a - 1.0) * c + sa)
                nb1 = 2.0 * a * ((a - 1.0) - (a + 1.0) * c)
                nb2 = a * ((a + 1.0) - (a - 1.0) * c - sa)
                na0 = (a + 1.0) + (a - 1.0) * c + sa
                na1 = -2.0 * ((a - 1.0) + (a + 1.0) * c)
                na2 = (a + 1.0) + (a - 1.0) * c - sa
            }
            T_HIGH -> {
                val sa = 2.0 * sqrt(a) * (s / 2.0 * sqrt(2.0))
                nb0 = a * ((a + 1.0) + (a - 1.0) * c + sa)
                nb1 = -2.0 * a * ((a - 1.0) + (a + 1.0) * c)
                nb2 = a * ((a + 1.0) + (a - 1.0) * c - sa)
                na0 = (a + 1.0) - (a - 1.0) * c + sa
                na1 = 2.0 * ((a - 1.0) - (a + 1.0) * c)
                na2 = (a + 1.0) - (a - 1.0) * c - sa
            }
            T_HP -> {
                val al = s / (2.0 * q)
                nb0 = (1.0 + c) / 2.0
                nb1 = -(1.0 + c)
                nb2 = (1.0 + c) / 2.0
                na0 = 1.0 + al
                na1 = -2.0 * c
                na2 = 1.0 - al
            }
            else -> {
                val al = s / (2.0 * q)
                nb0 = (1.0 - c) / 2.0
                nb1 = 1.0 - c
                nb2 = (1.0 - c) / 2.0
                na0 = 1.0 + al
                na1 = -2.0 * c
                na2 = 1.0 - al
            }
        }
        b0 = nb0 / na0
        b1 = nb1 / na0
        b2 = nb2 / na0
        a1 = na1 / na0
        a2 = na2 / na0
    }
}

/** Mengisi filter dari parameter. Dipakai oleh pemroses audio dan oleh grafik respons. */
fun configureFilters(p: ChParams, fs: Double, eq: Array<Biquad>, hp: Array<Biquad>, lp: Array<Biquad>) {
    for (i in eq.indices) {
        val b = p.eq[i]
        val on = p.eqOn && abs(b.g) > 0.001
        eq[i].active = on
        if (on) eq[i].set(b.type, b.f, b.g, b.q, fs)
    }
    for (k in 0..1) {
        val hon = p.hpOn && (k == 0 || p.slope == 24)
        hp[k].active = hon
        if (hon) hp[k].set(T_HP, p.hpF, 0.0, 0.70710678, fs)
        val lon = p.lpOn && (k == 0 || p.slope == 24)
        lp[k].active = lon
        if (lon) lp[k].set(T_LP, p.lpF, 0.0, 0.70710678, fs)
    }
}

/** Respons frekuensi gabungan EQ dan crossover satu kanal, dalam dB. */
fun responseDb(p: ChParams, fs: Double, freqs: DoubleArray): DoubleArray {
    val eq = Array(5) { Biquad() }
    val hp = Array(2) { Biquad() }
    val lp = Array(2) { Biquad() }
    configureFilters(p, fs, eq, hp, lp)
    val all = ArrayList<Biquad>()
    for (b in eq) if (b.active) all.add(b)
    for (b in hp) if (b.active) all.add(b)
    for (b in lp) if (b.active) all.add(b)
    return DoubleArray(freqs.size) { i ->
        val w = 2.0 * PI * freqs[i] / fs
        var m = 1.0
        for (b in all) m *= b.magnitude(w)
        20.0 * log10(max(m, 1e-5))
    }
}

/** Rantai pengolah satu kanal: fase, delay, EQ, crossover, kompresor, level. */
class ChannelDsp {
    private val eq = Array(5) { Biquad() }
    private val hp = Array(2) { Biquad() }
    private val lp = Array(2) { Biquad() }
    private var buf = FloatArray(4)
    private var wp = 0
    private var delaySamples = 0
    private var inv = 1.0
    private var outGain = 1.0
    private var compOn = false
    private var thr = -24.0
    private var ratio = 4.0
    private var knee = 12.0
    private var atkC = 0.0
    private var relC = 0.0
    private var makeupDb = 0.0
    private var grS = 0.0

    var peakBlock = 0f
    var grBlock = 0f

    fun configure(p: ChParams, fs: Double, masterDb: Double) {
        configureFilters(p, fs, eq, hp, lp)
        val need = (fs * 0.06).toInt() + 4
        if (buf.size != need) {
            buf = FloatArray(need)
            wp = 0
        }
        delaySamples = min(need - 2, max(0, (p.delayMs * fs / 1000.0).roundToInt()))
        inv = if (p.invert) -1.0 else 1.0
        outGain = if (p.mute) 0.0 else 10.0.pow((p.trimDb + masterDb) / 20.0)
        compOn = p.compOn
        thr = p.thr
        ratio = max(p.ratio, 1.0)
        knee = max(p.knee, 0.001)
        makeupDb = p.makeup
        atkC = exp(-1.0 / (max(p.atk, 0.1) * 0.001 * fs))
        relC = exp(-1.0 / (max(p.rel, 1.0) * 0.001 * fs))
    }

    fun reset() {
        for (f in eq) f.reset()
        for (f in hp) f.reset()
        for (f in lp) f.reset()
        java.util.Arrays.fill(buf, 0f)
        wp = 0
        grS = 0.0
    }

    fun process(x: Float): Float {
        var v = x.toDouble() * inv
        if (delaySamples > 0) {
            buf[wp] = v.toFloat()
            var rp = wp - delaySamples
            if (rp < 0) rp += buf.size
            wp++
            if (wp >= buf.size) wp = 0
            v = buf[rp].toDouble()
        }
        for (f in eq) if (f.active) v = f.process(v)
        for (f in hp) if (f.active) v = f.process(v)
        for (f in lp) if (f.active) v = f.process(v)
        if (compOn) {
            val a = abs(v)
            val lvl = if (a < 1e-6) -120.0 else ln(a) * 8.685889638065035
            val over = lvl - thr
            val out = if (2.0 * over < -knee) {
                lvl
            } else if (2.0 * abs(over) <= knee) {
                val t = over + knee / 2.0
                lvl + (1.0 / ratio - 1.0) * t * t / (2.0 * knee)
            } else {
                thr + over / ratio
            }
            val gr = out - lvl
            val c = if (gr < grS) atkC else relC
            grS = c * grS + (1.0 - c) * gr
            v *= exp((grS + makeupDb) * 0.1151292546497023)
        } else {
            grS = 0.0
        }
        v *= outGain
        if (v.isNaN() || v.isInfinite()) {
            v = 0.0
            reset()
        }
        val av = abs(v).toFloat()
        if (av > peakBlock) peakBlock = av
        grBlock = (-grS).toFloat()
        return v.toFloat()
    }
}

/** Dua kanal: kiri dan kanan memakai pengaturan masing-masing. */
class StereoEngine {
    val l = ChannelDsp()
    val r = ChannelDsp()
    private var seen = -1
    private var fs = 48000.0
    private var fsSeen = 0.0

    fun setRate(f: Double) {
        fs = f
    }

    fun sync() {
        if (seen != Fx.rev || fsSeen != fs) {
            synchronized(Fx.lock) {
                l.configure(Fx.params[0], fs, Fx.masterDb)
                r.configure(Fx.params[1], fs, Fx.masterDb)
                seen = Fx.rev
            }
            fsSeen = fs
        }
    }

    fun reset() {
        l.reset()
        r.reset()
    }
}

/** Pengaturan yang dipakai bersama oleh layar dan pemroses audio. */
object Fx {
    val params = arrayOf(ChParams(), ChParams())
    val lock = Any()

    @Volatile
    var rev = 0

    @Volatile
    var masterDb = 0.0

    @Volatile
    var linked = false
    var loaded = false
    val peak = FloatArray(2)
    val gr = FloatArray(2)
    var onChange: (() -> Unit)? = null

    fun edit(chs: IntArray, f: (ChParams) -> Unit) {
        synchronized(lock) {
            for (c in chs) f(params[c])
            rev++
        }
        onChange?.invoke()
    }

    fun setMaster(db: Double) {
        synchronized(lock) {
            masterDb = db
            rev++
        }
        onChange?.invoke()
    }
}
