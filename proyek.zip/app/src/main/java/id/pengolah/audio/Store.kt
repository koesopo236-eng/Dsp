package id.pengolah.audio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Track(val uri: String, val name: String, val durMs: Long)

class Preset(var name: String, var data: JSONArray)

class Saved {
    var repeat = 0
    var shuffle = false
    var lastIndex = -1
    var lastPos = 0L
}

/** Penyimpanan di perangkat: daftar lagu, preset, dan pengaturan terakhir. */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("pengolah_audio", Context.MODE_PRIVATE)

    fun loadLibrary(c: Context): MutableList<Track> {
        val out = ArrayList<Track>()
        try {
            val a = JSONArray(sp(c).getString("library", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Track(o.getString("u"), o.optString("n", "Lagu"), o.optLong("d", 0L)))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveLibrary(c: Context, list: List<Track>) {
        val a = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("u", t.uri)
            o.put("n", t.name)
            o.put("d", t.durMs)
            a.put(o)
        }
        sp(c).edit().putString("library", a.toString()).apply()
    }

    fun loadPresets(c: Context): MutableList<Preset> {
        val out = ArrayList<Preset>()
        try {
            val a = JSONArray(sp(c).getString("presets", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Preset(o.getString("name"), o.getJSONArray("data")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun savePresets(c: Context, list: List<Preset>) {
        val a = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("name", p.name)
            o.put("data", p.data)
            a.put(o)
        }
        sp(c).edit().putString("presets", a.toString()).apply()
    }

    /** Memuat pengaturan terakhir ke Fx (hanya sekali per proses) dan mengembalikan sisanya. */
    fun loadSettings(c: Context): Saved {
        val s = Saved()
        try {
            val j = JSONObject(sp(c).getString("settings", "{}"))
            s.repeat = j.optInt("repeat", 0)
            s.shuffle = j.optBoolean("shuffle", false)
            s.lastIndex = j.optInt("li", -1)
            s.lastPos = j.optLong("lp", 0L)
            if (!Fx.loaded) {
                synchronized(Fx.lock) {
                    val arr = j.optJSONArray("p")
                    if (arr != null) {
                        Fx.params[0].loadJson(arr.optJSONObject(0))
                        Fx.params[1].loadJson(arr.optJSONObject(1))
                    }
                    Fx.masterDb = j.optDouble("master", 0.0)
                    Fx.linked = j.optBoolean("linked", false)
                    Fx.rev++
                }
                Fx.loaded = true
            }
        } catch (e: Exception) {
            Fx.loaded = true
        }
        return s
    }

    fun saveSettings(c: Context, s: Saved) {
        try {
            val j = JSONObject()
            val arr = JSONArray()
            synchronized(Fx.lock) {
                arr.put(Fx.params[0].toJson())
                arr.put(Fx.params[1].toJson())
            }
            j.put("p", arr)
            j.put("master", Fx.masterDb)
            j.put("linked", Fx.linked)
            j.put("repeat", s.repeat)
            j.put("shuffle", s.shuffle)
            j.put("li", s.lastIndex)
            j.put("lp", s.lastPos)
            sp(c).edit().putString("settings", j.toString()).apply()
        } catch (e: Exception) {
        }
    }
}
