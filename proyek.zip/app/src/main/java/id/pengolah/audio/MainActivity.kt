package id.pengolah.audio

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.InputFilter
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

private val BG = 0xFF0F1317.toInt()
private val SURF = 0xFF171C22.toInt()
private val SURF2 = 0xFF1F262D.toInt()
private val LINE = 0xFF2A323A.toInt()
private val INK = 0xFFE7EBEF.toInt()
private val MUTED = 0xFF8E9AA6.toInt()
private val CL = 0xFF4FA6FF.toInt()
private val CR = 0xFFFF7B55.toInt()
private val ACC = 0xFFB9C4CF.toInt()
private val ONC = 0xFF07101A.toInt()
private val CLIP = 0xFFD11A2A.toInt()
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private fun chColor(ch: Int): Int = if (ch == 0) CL else CR

class MainActivity : Activity() {
    companion object {
        const val REQ_PICK = 11
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var player: ExoPlayer
    private var controller: MediaController? = null
    private var saved = Saved()
    private var library: MutableList<Track> = ArrayList()
    private var presets: MutableList<Preset> = ArrayList()

    private val refreshers = arrayOf(ArrayList<() -> Unit>(), ArrayList<() -> Unit>())
    private val curves = arrayOfNulls<CurveView>(2)
    private val peakTxt = arrayOfNulls<TextView>(2)
    private val grTxt = arrayOfNulls<TextView>(2)
    private val meters = arrayOfNulls<MeterView>(2)
    private val panels = arrayOfNulls<LinearLayout>(2)
    private val tabBtns = arrayOfNulls<Button>(2)
    private val disp = doubleArrayOf(-90.0, -90.0)

    private lateinit var titleTv: TextView
    private lateinit var timeTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: Button
    private lateinit var repeatBtn: Button
    private lateinit var shuffleBtn: Button
    private lateinit var libTitle: TextView
    private lateinit var libBox: LinearLayout
    private lateinit var presetName: EditText
    private lateinit var presetMsg: TextView
    private lateinit var presetBox: LinearLayout
    private var seeking = false

    // ---------------------------------------------------------------- siklus hidup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = Engine.player(this)
        saved = Store.loadSettings(this)
        library = Store.loadLibrary(this)
        presets = Store.loadPresets(this)
        syncPlaylist()
        Fx.onChange = { scheduleSave() }
        buildUi()
        player.addListener(listener)
        connectController()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onStart() {
        super.onStart()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    override fun onStop() {
        ui.removeCallbacks(tick)
        saveNow()
        super.onStop()
    }

    override fun onDestroy() {
        Fx.onChange = null
        player.removeListener(listener)
        controller?.release()
        controller = null
        super.onDestroy()
    }

    private fun connectController() {
        try {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            val fut = MediaController.Builder(this, token).buildAsync()
            fut.addListener({
                try {
                    controller = fut.get()
                } catch (e: Exception) {
                }
            }, ContextCompat.getMainExecutor(this))
        } catch (e: Exception) {
        }
    }

    private fun item(t: Track): MediaItem =
        MediaItem.Builder()
            .setUri(Uri.parse(t.uri))
            .setMediaId(t.uri)
            .setMediaMetadata(
                MediaMetadata.Builder().setTitle(t.name).setArtist("Pengolah Audio L/R").build()
            )
            .build()

    private fun syncPlaylist() {
        if (player.mediaItemCount == 0 && library.isNotEmpty()) {
            val items = library.map { item(it) }
            if (saved.lastIndex in library.indices) {
                player.setMediaItems(items, saved.lastIndex, saved.lastPos)
            } else {
                player.setMediaItems(items)
            }
            player.repeatMode = saved.repeat
            player.shuffleModeEnabled = saved.shuffle
            player.prepare()
        }
    }

    // ---------------------------------------------------------------- simpan

    private val saveRun = Runnable { saveNow() }

    private fun scheduleSave() {
        ui.removeCallbacks(saveRun)
        ui.postDelayed(saveRun, 500)
    }

    private fun saveNow() {
        val s = Saved()
        s.repeat = player.repeatMode
        s.shuffle = player.shuffleModeEnabled
        if (player.mediaItemCount > 0) {
            s.lastIndex = player.currentMediaItemIndex
            s.lastPos = player.currentPosition
        }
        Store.saveSettings(this, s)
    }

    // ---------------------------------------------------------------- pembantu tampilan

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rect(fill: Int, stroke: Int = 0, r: Int = 6): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(r).toFloat()
        if (stroke != 0) d.setStroke(dp(1), stroke)
        return d
    }

    private fun tv(
        t: CharSequence,
        size: Float = 14f,
        color: Int = INK,
        bold: Boolean = false,
        mono: Boolean = false
    ): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        if (mono) v.typeface = Typeface.MONOSPACE
        return v
    }

    private fun vbox(pad: Int = 0): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        return l
    }

    private fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    private fun lpW(w: Int, h: Int, wt: Float = 0f, top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, wt)
        p.topMargin = dp(top)
        return p
    }

    private fun gap(): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(0, WRAP, 1f)
        p.rightMargin = dp(6)
        return p
    }

    private fun card(): LinearLayout {
        val c = vbox(12)
        c.background = rect(SURF, LINE, 6)
        return c
    }

    private fun btn(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(INK)
        b.textSize = 13f
        b.minHeight = 0
        b.minimumHeight = dp(40)
        b.minWidth = 0
        b.minimumWidth = dp(40)
        b.setPadding(dp(12), 0, dp(12), 0)
        b.background = rect(SURF2, LINE, 4)
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    private fun styleOn(b: Button, on: Boolean, color: Int) {
        b.background = rect(if (on) color else SURF2, if (on) color else LINE, 4)
        b.setTextColor(if (on) ONC else INK)
    }

    private fun fdb(v: Double): String =
        (if (v > 0.05) "+" else if (v < -0.05) "−" else "") + "%.1f dB".format(kotlin.math.abs(v))

    private fun fhz(v: Double): String =
        if (v >= 1000.0) "%.2f kHz".format(v / 1000.0) else "%d Hz".format(v.roundToInt())

    private fun fms(v: Double): String = "%.1f ms".format(v)

    private fun fmtTime(ms: Long): String {
        val s = max(0L, ms) / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun stepper(t: String, act: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.textSize = 18f
        b.setTextColor(INK)
        b.minWidth = 0
        b.minHeight = 0
        b.minimumWidth = dp(40)
        b.minimumHeight = dp(40)
        b.setPadding(0, 0, 0, 0)
        b.background = rect(SURF2, LINE, 4)
        b.stateListAnimator = null
        val rep = object : Runnable {
            override fun run() {
                act()
                ui.postDelayed(this, 70)
            }
        }
        b.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    v.isPressed = true
                    act()
                    ui.postDelayed(rep, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    ui.removeCallbacks(rep)
                }
            }
            true
        }
        return b
    }

    /** Slider dengan tombol − dan + di sampingnya. Mengembalikan fungsi penyegar tampilan. */
    private fun sliderRow(
        parent: ViewGroup,
        color: Int,
        label: String,
        lo: Double,
        hi: Double,
        step: Double,
        log: Boolean,
        fmt: (Double) -> String,
        get: () -> Double,
        set: (Double) -> Unit
    ): () -> Unit {
        val box = vbox()
        val head = hbox()
        val value = tv("", 12f, INK, mono = true)
        head.addView(tv(label, 12f, MUTED), lpW(0, WRAP, 1f))
        head.addView(value, lpW(WRAP, WRAP))
        box.addView(head)
        val bar = SeekBar(this)
        bar.max = 1000
        bar.progressTintList = ColorStateList.valueOf(color)
        bar.thumbTintList = ColorStateList.valueOf(color)

        fun toP(v: Double): Int {
            val f = if (log) ln(v / lo) / ln(hi / lo) else (v - lo) / (hi - lo)
            return (f.coerceIn(0.0, 1.0) * 1000.0).roundToInt()
        }

        fun toV(p: Int): Double {
            val f = p / 1000.0
            var v = if (log) lo * (hi / lo).pow(f) else lo + f * (hi - lo)
            if (!log && step > 0.0) v = (v / step).roundToInt() * step
            return v.coerceIn(lo, hi)
        }

        val show: () -> Unit = {
            val v = get()
            bar.progress = toP(v)
            value.text = fmt(v)
        }

        fun nudge(dir: Int) {
            val cur = get()
            var nv = if (log) {
                cur * (hi / lo).pow(dir / 200.0)
            } else {
                cur + dir * (if (step > 0.0) step else (hi - lo) / 100.0)
            }
            if (!log && step > 0.0) nv = (nv / step).roundToInt() * step
            set(nv.coerceIn(lo, hi))
            show()
        }

        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    set(toV(p))
                    show()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val line = hbox()
        line.addView(stepper("−") { nudge(-1) }, lpW(dp(40), dp(40)))
        line.addView(bar, lpW(0, WRAP, 1f))
        line.addView(stepper("+") { nudge(1) }, lpW(dp(40), dp(40)))
        box.addView(line)
        parent.addView(box, lpW(MATCH, WRAP, top = 8))
        show()
        return show
    }

    private fun section(parent: ViewGroup, title: String, open: Boolean): LinearLayout {
        val head = tv("", 14f, INK, bold = true)
        val body = vbox()
        body.visibility = if (open) View.VISIBLE else View.GONE

        fun upd() {
            head.text = (if (body.visibility == View.VISIBLE) "−  " else "+  ") + title.uppercase()
        }
        head.setOnClickListener {
            body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            upd()
        }
        head.setPadding(0, dp(14), 0, dp(8))
        upd()
        parent.addView(head)
        parent.addView(body)
        return body
    }

    // ---------------------------------------------------------------- pengaturan per kanal

    private fun targets(ch: Int): IntArray = if (Fx.linked) intArrayOf(0, 1) else intArrayOf(ch)

    private fun editCh(ch: Int, f: (ChParams) -> Unit) {
        val t = targets(ch)
        Fx.edit(t, f)
        for (c in t) refreshCh(c)
    }

    private fun refreshCh(ch: Int) {
        for (r in refreshers[ch]) r()
        curves[ch]?.invalidate()
    }

    private fun refreshAll() {
        refreshCh(0)
        refreshCh(1)
    }

    private fun reg(ch: Int, f: () -> Unit) {
        refreshers[ch].add(f)
    }

    private fun chSlider(
        parent: ViewGroup,
        ch: Int,
        label: String,
        lo: Double,
        hi: Double,
        step: Double,
        log: Boolean,
        fmt: (Double) -> String,
        get: (ChParams) -> Double,
        set: (ChParams, Double) -> Unit
    ) {
        val show = sliderRow(
            parent, chColor(ch), label, lo, hi, step, log, fmt,
            { get(Fx.params[ch]) },
            { v -> editCh(ch) { set(it, v) } }
        )
        reg(ch, show)
    }

    private fun chToggle(
        parent: ViewGroup,
        ch: Int,
        label: String,
        get: (ChParams) -> Boolean,
        set: (ChParams, Boolean) -> Unit
    ) {
        val b = btn(label) {}
        val color = chColor(ch)
        val show: () -> Unit = { styleOn(b, get(Fx.params[ch]), color) }
        b.setOnClickListener {
            val nv = !get(Fx.params[ch])
            editCh(ch) { set(it, nv) }
        }
        show()
        reg(ch, show)
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.rightMargin = dp(8)
        parent.addView(b, lp)
    }

    private fun chSeg(
        parent: ViewGroup,
        ch: Int,
        opts: List<Pair<Int, String>>,
        get: (ChParams) -> Int,
        set: (ChParams, Int) -> Unit
    ) {
        val row = hbox()
        val color = chColor(ch)
        val bs = ArrayList<Pair<Int, Button>>()
        for (o in opts) {
            val v = o.first
            val b = btn(o.second) {}
            b.setOnClickListener { editCh(ch) { set(it, v) } }
            bs.add(Pair(v, b))
            row.addView(b, gap())
        }
        val show: () -> Unit = {
            val cur = get(Fx.params[ch])
            for (x in bs) styleOn(x.second, x.first == cur, color)
        }
        show()
        reg(ch, show)
        parent.addView(row, lpW(MATCH, WRAP, top = 6))
    }

    private fun buildPanel(ch: Int): LinearLayout {
        val p = card()
        val head = hbox()
        val badge = tv(if (ch == 0) "L" else "R", 16f, ONC, bold = true)
        badge.gravity = Gravity.CENTER
        badge.background = rect(chColor(ch), 0, 3)
        head.addView(badge, lpW(dp(30), dp(30)))
        val meter = MeterView(ch)
        meters[ch] = meter
        val ml = lpW(0, dp(8), 1f)
        ml.leftMargin = dp(10)
        ml.rightMargin = dp(8)
        head.addView(meter, ml)
        val pk = tv("−∞", 12f, MUTED, mono = true)
        pk.minWidth = dp(64)
        pk.gravity = Gravity.END
        peakTxt[ch] = pk
        head.addView(pk, lpW(WRAP, WRAP))
        val rs = btn("Reset") { editCh(ch) { it.copyFrom(ChParams()) } }
        val rl = lpW(WRAP, WRAP)
        rl.leftMargin = dp(8)
        head.addView(rs, rl)
        p.addView(head)

        val cv = CurveView(ch)
        curves[ch] = cv
        p.addView(cv, lpW(MATCH, dp(150), top = 10))
        p.addView(tv("Respons gabungan EQ dan crossover, 20 Hz sampai 20 kHz, skala ±24 dB.", 11f, MUTED), lpW(MATCH, WRAP, top = 4))

        val s1 = section(p, "Level, fase, delay", true)
        val r1 = hbox()
        chToggle(r1, ch, "Balik fase (Ø)", { it.invert }, { c, v -> c.invert = v })
        chToggle(r1, ch, "Bisu", { it.mute }, { c, v -> c.mute = v })
        s1.addView(r1)
        chSlider(s1, ch, "Level kanal", -24.0, 12.0, 0.1, false, { fdb(it) }, { it.trimDb }, { c, v -> c.trimDb = v })
        chSlider(s1, ch, "Delay", 0.0, 50.0, 0.05, false,
            { "%.2f ms · %.1f cm".format(it, it * 34.3) }, { it.delayMs }, { c, v -> c.delayMs = v })

        val s2 = section(p, "EQ parametrik", true)
        val r2 = hbox()
        chToggle(r2, ch, "EQ aktif", { it.eqOn }, { c, v -> c.eqOn = v })
        s2.addView(r2)
        for (k in 0..4) {
            s2.addView(tv("Pita ${k + 1}", 13f, INK, bold = true), lpW(WRAP, WRAP, top = 14))
            chSeg(s2, ch, listOf(Pair(T_PEAK, "Puncak"), Pair(T_LOW, "Rak rendah"), Pair(T_HIGH, "Rak tinggi")),
                { it.eq[k].type }, { c, v -> c.eq[k].type = v })
            chSlider(s2, ch, "Frekuensi", 20.0, 20000.0, 0.0, true, { fhz(it) }, { it.eq[k].f }, { c, v -> c.eq[k].f = v })
            chSlider(s2, ch, "Gain", -18.0, 18.0, 0.1, false, { fdb(it) }, { it.eq[k].g }, { c, v -> c.eq[k].g = v })
            chSlider(s2, ch, "Q (hanya mode Puncak)", 0.1, 10.0, 0.0, true, { "%.2f".format(it) }, { it.eq[k].q }, { c, v -> c.eq[k].q = v })
        }

        val s3 = section(p, "Crossover", false)
        val r3 = hbox()
        chToggle(r3, ch, "High-pass", { it.hpOn }, { c, v -> c.hpOn = v })
        chToggle(r3, ch, "Low-pass", { it.lpOn }, { c, v -> c.lpOn = v })
        s3.addView(r3)
        chSlider(s3, ch, "Frekuensi high-pass", 20.0, 2000.0, 0.0, true, { fhz(it) }, { it.hpF }, { c, v -> c.hpF = v })
        chSlider(s3, ch, "Frekuensi low-pass", 200.0, 20000.0, 0.0, true, { fhz(it) }, { it.lpF }, { c, v -> c.lpF = v })
        s3.addView(tv("Kemiringan", 12f, MUTED), lpW(WRAP, WRAP, top = 10))
        chSeg(s3, ch, listOf(Pair(12, "12 dB/oktaf"), Pair(24, "24 dB/oktaf (LR)")), { it.slope }, { c, v -> c.slope = v })
        s3.addView(tv("Menyalakan keduanya membuat filter band-pass.", 11f, MUTED), lpW(MATCH, WRAP, top = 6))

        val s4 = section(p, "Kompresor", false)
        val r4 = hbox()
        chToggle(r4, ch, "Kompresor aktif", { it.compOn }, { c, v -> c.compOn = v })
        s4.addView(r4)
        chSlider(s4, ch, "Threshold", -60.0, 0.0, 1.0, false, { "%.0f dB".format(it) }, { it.thr }, { c, v -> c.thr = v })
        chSlider(s4, ch, "Rasio", 1.0, 20.0, 0.5, false, { "%.1f : 1".format(it) }, { it.ratio }, { c, v -> c.ratio = v })
        chSlider(s4, ch, "Attack", 0.5, 200.0, 0.0, true, { fms(it) }, { it.atk }, { c, v -> c.atk = v })
        chSlider(s4, ch, "Release", 20.0, 1000.0, 0.0, true, { fms(it) }, { it.rel }, { c, v -> c.rel = v })
        chSlider(s4, ch, "Knee", 0.0, 40.0, 1.0, false, { "%.0f dB".format(it) }, { it.knee }, { c, v -> c.knee = v })
        chSlider(s4, ch, "Makeup gain", 0.0, 24.0, 0.5, false, { fdb(it) }, { it.makeup }, { c, v -> c.makeup = v })
        val g = tv("Gain reduction: 0.0 dB", 12f, MUTED, mono = true)
        grTxt[ch] = g
        s4.addView(g, lpW(WRAP, WRAP, top = 10))
        return p
    }

    // ---------------------------------------------------------------- grafik dan meter

    inner class CurveView(private val ch: Int) : View(this@MainActivity) {
        private val freqs = DoubleArray(160) { 20.0 * 1000.0.pow(it / 159.0) }
        private val pGrid = Paint()
        private val pTxt = Paint()
        private val pLine = Paint()
        private val pFill = Paint()
        private val path = Path()

        init {
            setBackgroundColor(BG)
            pGrid.color = LINE
            pGrid.strokeWidth = dp(1).toFloat()
            pTxt.color = MUTED
            pTxt.textSize = dp(10).toFloat()
            pTxt.isAntiAlias = true
            pLine.color = chColor(ch)
            pLine.style = Paint.Style.STROKE
            pLine.strokeWidth = dp(2).toFloat()
            pLine.isAntiAlias = true
            pFill.color = chColor(ch)
            pFill.style = Paint.Style.FILL
            pFill.alpha = 40
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            val range = 24.0
            fun yOf(v: Double): Float = h / 2f - (v.coerceIn(-range, range) / range).toFloat() * (h / 2f - dp(8))
            fun xOf(f: Double): Float = (ln(f / 20.0) / ln(1000.0) * w).toFloat()
            for (v in intArrayOf(-12, 0, 12)) {
                val y = yOf(v.toDouble())
                canvas.drawLine(0f, y, w, y, pGrid)
                val lb = (if (v > 0) "+" else if (v < 0) "−" else "") + kotlin.math.abs(v)
                canvas.drawText(lb, dp(4).toFloat(), y - dp(2), pTxt)
            }
            val marks = doubleArrayOf(100.0, 1000.0, 10000.0)
            val names = arrayOf("100", "1k", "10k")
            for (i in marks.indices) {
                val x = xOf(marks[i])
                canvas.drawLine(x, 0f, x, h, pGrid)
                canvas.drawText(names[i], x + dp(3), h - dp(4), pTxt)
            }
            val r = responseDb(Fx.params[ch], 48000.0, freqs)
            path.reset()
            for (i in freqs.indices) {
                val x = xOf(freqs[i])
                val y = yOf(r[i])
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, pLine)
            path.lineTo(w, yOf(0.0))
            path.lineTo(0f, yOf(0.0))
            path.close()
            canvas.drawPath(path, pFill)
        }
    }

    inner class MeterView(private val ch: Int) : View(this@MainActivity) {
        private val pBg = Paint()
        private val pFg = Paint()
        private val pClip = Paint()

        init {
            pBg.color = LINE
            pFg.color = chColor(ch)
            pClip.color = CLIP
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            canvas.drawRect(0f, 0f, w, h, pBg)
            val pct = ((disp[ch] + 60.0) / 60.0).coerceIn(0.0, 1.0).toFloat()
            canvas.drawRect(0f, 0f, w * pct, h, if (disp[ch] > -0.5) pClip else pFg)
        }
    }

    // ---------------------------------------------------------------- bagian layar

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        val root = vbox(14)
        scroll.addView(root, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(tv("Pengolah Audio L/R", 24f, INK, bold = true))
        root.addView(tv("Putar lagu dari HP, atur kiri dan kanan sendiri-sendiri.", 13f, MUTED), lpW(MATCH, WRAP, top = 2))
        root.addView(buildPlayer(), lpW(MATCH, WRAP, top = 14))
        root.addView(buildLibrary(), lpW(MATCH, WRAP, top = 12))
        root.addView(buildPresets(), lpW(MATCH, WRAP, top = 12))
        root.addView(buildLinkRow(), lpW(MATCH, WRAP, top = 12))
        root.addView(buildTabs(), lpW(MATCH, WRAP, top = 8))
        for (ch in 0..1) {
            val p = buildPanel(ch)
            panels[ch] = p
            root.addView(p, lpW(MATCH, WRAP, top = 8))
        }
        showTab(0)
        setContentView(scroll)
        updateTitle()
    }

    private fun buildPlayer(): LinearLayout {
        val c = card()
        titleTv = tv("Belum ada lagu", 16f, INK, bold = true)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        c.addView(titleTv)

        seek = SeekBar(this)
        seek.max = 1000
        seek.progressTintList = ColorStateList.valueOf(ACC)
        seek.thumbTintList = ColorStateList.valueOf(ACC)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val d = durationMs()
                    timeTv.text = fmtTime(d * p / 1000) + " / " + fmtTime(d)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                seeking = true
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                seeking = false
                val d = durationMs()
                if (d > 0 && player.mediaItemCount > 0) player.seekTo(d * seek.progress / 1000)
            }
        })
        c.addView(seek, lpW(MATCH, WRAP, top = 8))
        timeTv = tv("0:00 / 0:00", 12f, MUTED, mono = true)
        c.addView(timeTv)

        val row = hbox()
        row.addView(btn("‹ Lagu") { prevTrack() }, gap())
        playBtn = btn("Putar") { togglePlay() }
        row.addView(playBtn, gap())
        row.addView(btn("Lagu ›") { player.seekToNextMediaItem() }, gap())
        c.addView(row, lpW(MATCH, WRAP, top = 10))

        val row2 = hbox()
        repeatBtn = btn("") {
            player.repeatMode = when (player.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
            refreshModes()
            scheduleSave()
        }
        shuffleBtn = btn("Acak") {
            player.shuffleModeEnabled = !player.shuffleModeEnabled
            refreshModes()
            scheduleSave()
        }
        row2.addView(repeatBtn, gap())
        row2.addView(shuffleBtn, gap())
        c.addView(row2, lpW(MATCH, WRAP, top = 8))
        refreshModes()

        sliderRow(c, ACC, "Volume master (di dalam aplikasi)", -48.0, 6.0, 0.5, false,
            { fdb(it) }, { Fx.masterDb }, { Fx.setMaster(it) })
        c.addView(tv("Mulai dari volume sistem kecil. Boost EQ dan makeup kompresor bisa membuat suara jauh lebih keras.", 11f, MUTED), lpW(MATCH, WRAP, top = 6))
        return c
    }

    private fun refreshModes() {
        repeatBtn.text = when (player.repeatMode) {
            Player.REPEAT_MODE_ALL -> "Ulang: semua"
            Player.REPEAT_MODE_ONE -> "Ulang: satu"
            else -> "Ulang: mati"
        }
        styleOn(repeatBtn, player.repeatMode != Player.REPEAT_MODE_OFF, ACC)
        styleOn(shuffleBtn, player.shuffleModeEnabled, ACC)
    }

    private fun durationMs(): Long {
        val d = player.duration
        return if (d == C.TIME_UNSET || d < 0) 0L else d
    }

    private fun togglePlay() {
        if (player.mediaItemCount == 0) {
            Toast.makeText(this, "Tambah lagu dulu", Toast.LENGTH_SHORT).show()
            return
        }
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0, 0L)
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.play()
        }
    }

    private fun prevTrack() {
        if (player.mediaItemCount == 0) return
        if (player.currentPosition > 3000) player.seekTo(0) else player.seekToPreviousMediaItem()
    }

    private fun updateTitle() {
        titleTv.text = if (player.mediaItemCount == 0) {
            "Belum ada lagu"
        } else {
            library.getOrNull(player.currentMediaItemIndex)?.name ?: ""
        }
    }

    private fun buildLibrary(): LinearLayout {
        val c = card()
        val head = hbox()
        libTitle = tv("Daftar lagu", 18f, INK, bold = true)
        head.addView(libTitle, lpW(0, WRAP, 1f))
        head.addView(btn("Tambah lagu") { pickSongs() }, lpW(WRAP, WRAP))
        c.addView(head)
        libBox = vbox()
        c.addView(libBox, lpW(MATCH, WRAP, top = 8))
        renderLibrary()
        return c
    }

    private fun renderLibrary() {
        libTitle.text = "Daftar lagu (${library.size})"
        libBox.removeAllViews()
        if (library.isEmpty()) {
            libBox.addView(tv("Belum ada lagu. Tekan Tambah lagu, lalu pilih satu atau banyak berkas sekaligus.", 13f, MUTED))
            return
        }
        val cur = if (player.mediaItemCount > 0) player.currentMediaItemIndex else -1
        for (i in library.indices) {
            val t = library[i]
            val row = hbox()
            val b = Button(this)
            b.text = "${i + 1}. ${t.name}   ${fmtTime(t.durMs)}"
            b.isAllCaps = false
            b.textSize = 13f
            b.setTextColor(INK)
            b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            b.maxLines = 1
            b.ellipsize = TextUtils.TruncateAt.END
            b.minHeight = 0
            b.minimumHeight = dp(44)
            b.setPadding(dp(12), 0, dp(12), 0)
            b.background = rect(SURF2, if (i == cur) INK else LINE, 4)
            b.stateListAnimator = null
            b.setOnClickListener { playIndex(i) }
            row.addView(b, lpW(0, WRAP, 1f))

            val del = btn("Hapus") {}
            var armed = false
            del.setOnClickListener {
                if (!armed) {
                    armed = true
                    del.text = "Yakin?"
                    ui.postDelayed({
                        armed = false
                        del.text = "Hapus"
                    }, 3000)
                } else {
                    removeTrack(i)
                }
            }
            val dl = lpW(WRAP, dp(44))
            dl.leftMargin = dp(6)
            row.addView(del, dl)
            libBox.addView(row, lpW(MATCH, WRAP, top = 6))
        }
    }

    private fun playIndex(i: Int) {
        if (i !in 0 until player.mediaItemCount) return
        player.seekTo(i, 0L)
        if (player.playbackState == Player.STATE_IDLE) player.prepare()
        player.play()
    }

    private fun removeTrack(i: Int) {
        if (i !in library.indices) return
        library.removeAt(i)
        if (i < player.mediaItemCount) player.removeMediaItem(i)
        Store.saveLibrary(this, library)
        renderLibrary()
        updateTitle()
    }

    private fun pickSongs() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "audio/*"
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(intent, REQ_PICK)
        } catch (e: Exception) {
            Toast.makeText(this, "Pemilih berkas tidak tersedia di HP ini", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        } else {
            val u = data.data
            if (u != null) uris.add(u)
        }
        addUris(uris)
    }

    private fun addUris(uris: List<Uri>) {
        Toast.makeText(this, "Menambah ${uris.size} berkas…", Toast.LENGTH_SHORT).show()
        Thread {
            val added = ArrayList<Track>()
            val known = HashSet<String>()
            for (t in library) known.add(t.uri)
            for (u in uris) {
                val s = u.toString()
                if (known.contains(s)) continue
                known.add(s)
                try {
                    contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                var name = "Lagu"
                try {
                    val cur = contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    if (cur != null) {
                        if (cur.moveToFirst()) {
                            val n = cur.getString(0)
                            if (n != null) name = n
                        }
                        cur.close()
                    }
                } catch (e: Exception) {
                }
                name = name.substringBeforeLast('.')
                var dur = 0L
                try {
                    val r = MediaMetadataRetriever()
                    r.setDataSource(this, u)
                    val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    if (d != null) dur = d.toLongOrNull() ?: 0L
                    r.release()
                } catch (e: Exception) {
                }
                added.add(Track(s, name, dur))
            }
            runOnUiThread {
                if (added.isNotEmpty()) {
                    val wasEmpty = player.mediaItemCount == 0
                    library.addAll(added)
                    player.addMediaItems(added.map { item(it) })
                    if (wasEmpty) player.prepare()
                    Store.saveLibrary(this, library)
                    renderLibrary()
                    updateTitle()
                }
                Toast.makeText(this, "${added.size} lagu ditambahkan", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    // ---------------------------------------------------------------- preset

    private fun buildPresets(): LinearLayout {
        val c = card()
        c.addView(tv("Preset", 18f, INK, bold = true))
        val row = hbox()
        presetName = EditText(this)
        presetName.hint = "Nama preset"
        presetName.setHintTextColor(MUTED)
        presetName.setTextColor(INK)
        presetName.textSize = 14f
        presetName.setSingleLine(true)
        presetName.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(40))
        presetName.background = rect(BG, LINE, 4)
        presetName.setPadding(dp(10), dp(8), dp(10), dp(8))
        row.addView(presetName, gap())
        row.addView(btn("Simpan") { savePreset() }, lpW(WRAP, WRAP))
        c.addView(row, lpW(MATCH, WRAP, top = 8))
        presetMsg = tv("Preset menyimpan pengaturan kanal L dan R sekaligus. Nama yang sama menimpa preset lama.", 11f, MUTED)
        c.addView(presetMsg, lpW(MATCH, WRAP, top = 6))
        presetBox = vbox()
        c.addView(presetBox, lpW(MATCH, WRAP, top = 4))
        renderPresets()
        return c
    }

    private fun snapshot(): JSONArray {
        val a = JSONArray()
        a.put(Fx.params[0].toJson())
        a.put(Fx.params[1].toJson())
        return a
    }

    private fun savePreset() {
        val n = presetName.text.toString().trim()
        if (n.isEmpty()) {
            presetName.requestFocus()
            return
        }
        var at = -1
        for (i in presets.indices) if (presets[i].name == n) at = i
        if (at >= 0) presets[at].data = snapshot() else presets.add(Preset(n, snapshot()))
        Store.savePresets(this, presets)
        presetName.setText("")
        presetMsg.text = "Preset \"$n\" disimpan."
        renderPresets()
    }

    private fun loadPreset(p: Preset) {
        synchronized(Fx.lock) {
            Fx.params[0].loadJson(p.data.optJSONObject(0))
            Fx.params[1].loadJson(p.data.optJSONObject(1))
            Fx.rev++
        }
        refreshAll()
        scheduleSave()
        presetMsg.text = "Preset \"${p.name}\" dimuat."
    }

    private fun renderPresets() {
        presetBox.removeAllViews()
        if (presets.isEmpty()) {
            presetBox.addView(tv("Belum ada preset.", 13f, MUTED), lpW(WRAP, WRAP, top = 6))
            return
        }
        for (i in presets.indices) {
            val p = presets[i]
            val box = vbox()
            box.addView(tv(p.name, 14f, INK, bold = true), lpW(WRAP, WRAP, top = 12))
            val row = hbox()
            row.addView(btn("Muat") { loadPreset(p) }, gap())
            row.addView(btn("Timpa") {
                p.data = snapshot()
                Store.savePresets(this, presets)
                presetMsg.text = "Preset \"${p.name}\" diperbarui dengan pengaturan sekarang."
            }, gap())
            val del = btn("Hapus") {}
            var armed = false
            del.setOnClickListener {
                if (!armed) {
                    armed = true
                    del.text = "Yakin?"
                    ui.postDelayed({
                        armed = false
                        del.text = "Hapus"
                    }, 3000)
                } else {
                    presets.removeAt(i)
                    Store.savePresets(this, presets)
                    renderPresets()
                }
            }
            row.addView(del, gap())
            box.addView(row, lpW(MATCH, WRAP, top = 4))
            presetBox.addView(box)
        }
    }

    // ---------------------------------------------------------------- tautan dan tab

    private fun copyCh(a: Int, b: Int) {
        Fx.edit(intArrayOf(b)) { it.copyFrom(Fx.params[a]) }
        refreshAll()
    }

    private fun buildLinkRow(): LinearLayout {
        val r = hbox()
        val lk = btn("Tautkan L = R") {}
        val show: () -> Unit = { styleOn(lk, Fx.linked, ACC) }
        lk.setOnClickListener {
            Fx.linked = !Fx.linked
            if (Fx.linked) copyCh(0, 1)
            show()
            scheduleSave()
        }
        show()
        r.addView(lk, gap())
        r.addView(btn("Salin L → R") { copyCh(0, 1) }, gap())
        r.addView(btn("Salin R → L") { copyCh(1, 0) }, gap())
        return r
    }

    private fun buildTabs(): LinearLayout {
        val r = hbox()
        for (ch in 0..1) {
            val b = btn(if (ch == 0) "L   Kiri" else "R   Kanan") { showTab(ch) }
            tabBtns[ch] = b
            val lp = lpW(0, dp(48), 1f)
            if (ch == 0) lp.rightMargin = dp(8)
            r.addView(b, lp)
        }
        return r
    }

    private fun showTab(ch: Int) {
        for (i in 0..1) {
            panels[i]?.visibility = if (i == ch) View.VISIBLE else View.GONE
            val b = tabBtns[i]
            if (b != null) styleOn(b, i == ch, chColor(i))
        }
        curves[ch]?.invalidate()
    }

    // ---------------------------------------------------------------- pembaruan berkala

    private val tick = object : Runnable {
        override fun run() {
            updateUi()
            ui.postDelayed(this, 80)
        }
    }

    private fun updateUi() {
        val d = durationMs()
        val pos = player.currentPosition
        if (!seeking) {
            seek.progress = if (d > 0) (pos * 1000 / d).toInt() else 0
            timeTv.text = fmtTime(pos) + " / " + fmtTime(d)
        }
        playBtn.text = if (player.isPlaying) "Jeda" else "Putar"
        for (ch in 0..1) {
            val p = Fx.peak[ch]
            Fx.peak[ch] = 0f
            val db = if (p > 0.00001f) 20.0 * log10(p.toDouble()) else -90.0
            disp[ch] = max(db, disp[ch] - 3.0)
            meters[ch]?.invalidate()
            peakTxt[ch]?.text = if (disp[ch] > -80.0) "%.1f dB".format(disp[ch]) else "−∞"
            grTxt[ch]?.text = "Gain reduction: %.1f dB".format(Fx.gr[ch].toDouble())
        }
    }

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            renderLibrary()
            updateTitle()
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(
                this@MainActivity,
                "Gagal memutar: " + (error.message ?: "format tidak didukung"),
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
